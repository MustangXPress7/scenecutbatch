@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "dist\scenecutbatch.exe" (
    echo ERROR: No se encontro dist\scenecutbatch.exe
    echo Ejecuta primero install.bat para construir el ejecutable.
    pause
    exit /b 1
)
dist\scenecutbatch.exe %*
